--
-- PostgreSQL database dump
--

\restrict gbYkFErJN7XYsMEpkXSeK3skvPV5SB59isWOR8rKv8NPedMnRoYc7EDdjrjFXJ5

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg13+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: NA_A_ALARMSPEC; Type: TABLE DATA; Schema: public; Owner: -
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE public."NA_A_ALARMSPEC" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_A_ALARMSPEC" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_C_MQTT; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_C_MQTT" DISABLE TRIGGER ALL;

INSERT INTO public."NA_C_MQTT" (id, "NAME", "applicationName", "workflowManagerName", "brokerIp", "brokerPort", "topicPrefix", "clientId", "userName", password, "keepAliveSeconds", "reconnectDelayMs", state, description, "createTime", creator, editor, "editTime") VALUES (1, 'AMR001', 'ES01_P', 'elsaWorkflowManager', '192.168.0.3', 1883, 'amr/', 'ACS_EI_01', 'guest', 'guest', 30, 5000, 'DISCONNECTED', NULL, '2026-03-25 05:10:22.970062', 'admin', 'admin', '2026-05-11 01:54:46.101383');


ALTER TABLE public."NA_C_MQTT" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_M_CARRIER; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_M_CARRIER" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_M_CARRIER" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_BAY; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_BAY" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_BAY" (floor, description, "agvType", "chargeVoltage", "limitVoltage", "idleTime", "ZoneMove", "Traffic", "StopOut", "bayId", id) VALUES (1, '테스트 BAY', '', 28, 21, 0, '', '', '', 'DEMO', 1);


ALTER TABLE public."NA_R_BAY" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_LINK; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_LINK" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N002_N003', 'N002', 'N003', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N003_N004', 'N003', 'N004', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N004_N005', 'N004', 'N005', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N005_N006', 'N005', 'N006', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N006_N007', 'N006', 'N007', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N007_N008', 'N007', 'N008', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N008_N009', 'N008', 'N009', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N009_N010', 'N009', 'N010', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N010_N011', 'N010', 'N011', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N011_N012', 'N011', 'N012', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N012_N001', 'N012', 'N001', '0', 0, 0, NULL, 0, 0);
INSERT INTO public."NA_R_LINK" (id, "fromNodeId", "toNodeId", availability, length, speed, "agvType", load, "leftBranch") VALUES ('N001_N002', 'N001', 'N002', '0', 0, 0, NULL, 0, 0);


ALTER TABLE public."NA_R_LINK" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_LINK_ZONE; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_LINK_ZONE" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N003_N004_DEMO', 'N003_N004', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N004_N005_DEMO', 'N004_N005', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N005_N006_DEMO', 'N005_N006', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N006_N007_DEMO', 'N006_N007', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N007_N008_DEMO', 'N007_N008', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N010_N011_DEMO', 'N010_N011', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N011_N012_DEMO', 'N011_N012', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N012_N001_DEMO', 'N012_N001', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N001_N002_DEMO', 'N001_N002', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N002_N003_DEMO', 'N002_N003', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N008_N009_DEMO', 'N008_N009', 'DEMO', 'Y');
INSERT INTO public."NA_R_LINK_ZONE" (id, "linkId", "zoneId", "transferFlag") VALUES ('N009_N010_DEMO', 'N009_N010', 'DEMO', 'Y');


ALTER TABLE public."NA_R_LINK_ZONE" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_LOCATION; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_LOCATION" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_LOCATION" ("locationId", "stationId", type, "carrierType", state, direction, id) VALUES ('192.168.1.101:LEFT', 'N001', 'BUFFER', 'MAGAZINE', '', 'LEFT', 7);
INSERT INTO public."NA_R_LOCATION" ("locationId", "stationId", type, "carrierType", state, direction, id) VALUES ('192.168.1.103:LEFT', 'N007', 'BUFFER', 'MAGAZINE', '', 'LEFT', 8);
INSERT INTO public."NA_R_LOCATION" ("locationId", "stationId", type, "carrierType", state, direction, id) VALUES ('192.168.1.101:RIGHT', 'N001', 'BUFFER', 'MAGAZINE', '', 'LEFT', 9);
INSERT INTO public."NA_R_LOCATION" ("locationId", "stationId", type, "carrierType", state, direction, id) VALUES ('192.168.1.103:RIGHT', 'N007', 'BUFFER', 'MAGAZINE', '', 'LEFT', 10);


ALTER TABLE public."NA_R_LOCATION" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_NODE; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_NODE" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (34, 'N001', 'COMMON', 8.5, 8.5, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (35, 'N002', 'COMMON', 6.3, 9, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (36, 'N003', 'COMMON', 5.9, 11.5, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (37, 'N004', 'COMMON', 5.8, 14.05, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (38, 'N005', 'COMMON', 5.5, 16.7, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (39, 'N006', 'COMMON', 5, 18.6, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (40, 'N007', 'COMMON', 5.3, 20, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (41, 'N008', 'COMMON', 6.5, 18.5, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (42, 'N009', 'COMMON', 7.5, 16.6, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (43, 'N010', 'COMMON', 7.8, 14.46, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (44, 'N011', 'COMMON', 8.2, 12.6, 0);
INSERT INTO public."NA_R_NODE" (id, node_id, type, xpos, ypos, zpos) VALUES (45, 'N012', 'COMMON', 8.4, 10.1, 0);


ALTER TABLE public."NA_R_NODE" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_ORDER_PAIR; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_ORDER_PAIR" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_R_ORDER_PAIR" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_SPECIALCONFIG; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_SPECIALCONFIG" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_R_SPECIALCONFIG" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_STATION; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_STATION" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_STATION" (id, "linkId", type, distance, "Direction") VALUES ('N001', 'N001_N002', 'BOTH', 0, 'LEFT');
INSERT INTO public."NA_R_STATION" (id, "linkId", type, distance, "Direction") VALUES ('N007', 'N007_N008', 'BOTH', 0, 'LEFT');


ALTER TABLE public."NA_R_STATION" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_VEHICLE; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_VEHICLE" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_VEHICLE" ("LASTCHARGETIME", "LASTCHARGEBATTERY", "COMMID", vendor, version, "bayId", "carrierType", "connectionState", "alarmState", "processingState", "runState", "fullState", state, "batteryRate", "batteryVoltage", "currentNodeId", "acsDestNodeId", "vehicleDestNodeId", "transportCommandId", path, "nodeCheckTime", installed, "transferState", "eventTime", "plcVersion", "vehicleId", id, "COMMTYPE") VALUES ('2026-04-29 13:42:19.057+00', 100, 'AMR001', 'ROBINNO', '1.0', 'DEMO', 'MAGAZINE', 'DISCONNECT', 'ALARM', 'IDLE', 'STOP', 'EMPTY', 'ALIVE', 47, 25.27, 'N009', '', '', '', '', '2026-05-11 01:39:52.733711+00', 'T', 'NOTASSIGNED', '2026-05-11 01:42:00.768659+00', '1.0', '001', 8, 'MQTT');


ALTER TABLE public."NA_R_VEHICLE" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_R_ZONE; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_R_ZONE" DISABLE TRIGGER ALL;

INSERT INTO public."NA_R_ZONE" ("bayId", description, "zoneId", id) VALUES ('DEMO', '', 'DEMO', 1);


ALTER TABLE public."NA_R_ZONE" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_T_INTERSECTION; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_T_INTERSECTION" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_T_INTERSECTION" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_X_APPLICATION_MANAGER; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_X_APPLICATION_MANAGER" DISABLE TRIGGER ALL;



ALTER TABLE public."NA_X_APPLICATION_MANAGER" ENABLE TRIGGER ALL;

--
-- Data for Name: NA_X_OPTION; Type: TABLE DATA; Schema: public; Owner: -
--

ALTER TABLE public."NA_X_OPTION" DISABLE TRIGGER ALL;

INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1001', '1001', 'USEBALANCELOAD', '01', 'USED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1002', '1002', 'USEDYNAMICLOAD', '01', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1003', '1003', 'USEHEURISTICDELAY', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1004', '1004', 'USEBIDIRECTIONALNODE', '01', 'USED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1102', '1102', 'RULEFORSUITABLEMACHINEINGROUP', '01', 'FULLRATE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('1103', '1103', 'USEINTERNALROUTE', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2001', '2001', 'FORETRANSFERWHENDESTUNAVAILABLE', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2002', '2002', 'USETRANSPORTFAILWHENFIRSTTRANSPORT', '02', 'FALSE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2003', '2003', 'CONSIDERALTERNATEDJOBWHENTRANSFERRING', '01', 'USED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2005', '2005', 'CONSIDERALTERNATEDJOBWHENTRANSFERRING', '01', 'USED', '-1', 'TIME', 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2006', '2006', 'EXECUTEBATCHJOBINDUEORDER', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2007', '2007', 'AWAKELIMITCOUNTFORALTERNATEDJOB', '0', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('2008', '2008', 'FORETRANSFERWHENAWAKE', '01', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3001', '3001', 'SELECTTOBYSTOCKER', '01', 'TRUE', NULL, NULL, 'F');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3002', '3002', 'USESTAGECOMMAND', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3003', '3003', 'USESCANCOMMAND', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3004', '3004', 'USEPRIORITYCHANGECOMMAND', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3005', '3005', 'USEPORTINOUTTYPECHANGECOMMAND', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3006', '3006', 'USEUPDATECOMMAND', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3007', '3007', 'USEPERMITTEDCAPACITY', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3101', '3101', 'USEPORTINCREASINGPRIORITY', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3102', '3102', 'USESCANCOMMANDFORGARBAGECARRIER', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('3103', '3103', 'USEPRIORITYBOOSTUP', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('4001', '4001', 'USECARRIERPROCESSTYPE', '01', 'USED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5101', '5101', 'CONTROLMULTICRANEBYMCS', '02', 'FALSE', NULL, NULL, 'F');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5102', '5102', 'GARBAGECARRIERCONTROLRULEFORSTORAGE', '01', 'APPLICATIONSELECT', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5106', '5106', 'UNKNOWNCARRIERCONTROLRULEFORSTORAGE', '01', 'APPLICATIONSELECT', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5105', '5105', 'TRANSPORTRULEWHENPHYSICALFULL', '01', 'TOALTERNATESTORAGE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5201', '5201', 'CHECKPROCESSMACHINETRANSFERSTATE', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5301', '5301', 'CHECKRAILSTORAGEMACHINETRANSFERSTATE', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5206', '5206', 'USEWAITONPROCESSMACHINEFORUNLOADING', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5109', '5109', 'INSTALLCOMMANDWHENENHANCEDCARRIERLISTZERO', '01', 'USED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('5302', '5302', 'CHECKRAILSTORAGEMACHINEPORTOCCUPIED', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('6101', '6101', 'CHECKPROCESSMACHINEPORTOCCUPIED', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('6102', '6102', 'CHECKPROCESSMACHINEPORTSUBSTATE', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('6103', '6103', 'USERECOVERYTRANSPORTONPROCESSMACHINEPORT', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('6104', '6104', 'USECHANGEPREVIOUSCARRIERLOCATIONTONOTAPPLICABLEONPORT', '02', 'NOTUSED', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('7001', '7001', 'ACCEPTTRANSPORTREQUEST', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('7002', '7002', 'PERMITMATERIALMOVEMENT', '01', 'TRUE', NULL, NULL, 'T');
INSERT INTO public."NA_X_OPTION" (id, name, "nameDescription", value, "valueDescription", "subValue", "subValueDescription", used) VALUES ('7003', '7003', 'ACCEPTDESTCHANGEREQUEST', '01', 'TRUE', NULL, NULL, 'T');


ALTER TABLE public."NA_X_OPTION" ENABLE TRIGGER ALL;

--
-- Name: NA_C_MQTT_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_C_MQTT_id_seq"', 33, true);


--
-- Name: NA_R_BAY_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_R_BAY_id_seq"', 1, true);


--
-- Name: NA_R_LOCATION_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_R_LOCATION_id_seq"', 10, true);


--
-- Name: NA_R_NODE_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_R_NODE_id_seq"', 45, true);


--
-- Name: NA_R_VEHICLE_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_R_VEHICLE_id_seq"', 8, true);


--
-- Name: NA_R_ZONE_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."NA_R_ZONE_id_seq"', 1, true);


--
-- PostgreSQL database dump complete
--

\unrestrict gbYkFErJN7XYsMEpkXSeK3skvPV5SB59isWOR8rKv8NPedMnRoYc7EDdjrjFXJ5

